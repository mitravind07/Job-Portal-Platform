export const USER_API_ENDPOINT =
  "https://job-portal-api-dt5y.onrender.com/api/v1/user";
export const JOB_API_ENDPOINT =
  "https://job-portal-api-dt5y.onrender.com/api/v1/jobs";
export const APPLICATION_API_ENDPOINT =
  "https://job-portal-api-dt5y.onrender.com/api/v1/application";
export const COMPANY_API_ENDPOINT =
  "https://job-portal-api-dt5y.onrender.com/api/v1/company";
